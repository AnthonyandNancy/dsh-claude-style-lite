import { SESSION_SEARCH_ROUTE } from '../../constants'
import { currentSessionId, hostConversation, hostLayout, hostLocale, hostPluginNavigation, hostRemoteSkills, profileBundles, hostSessions, hostShortcuts, hostSlots, hostUiWorkspace, hostWorkspaces } from '@dsh-claude-style/engine/host'
import type { HostContext } from '@dsh-claude-style/engine/host'
import type { ContentHit, SearchAnswer } from '@dsh-claude-style/contracts/usage'
import type { HostConversationInput, HostConversationService, HostPluginBundle, HostSessionBinding, HostSessionSummary, HostShortcutRow, HostShortcutsService, HostSkill, HostSkillListAnswer, HostSlotsService, HostSlotStore, HostWorkspaceListSnapshot } from '@dsh-claude-style/contracts/services'
import { copy } from './copy'

/** The kinds of thing the palette lists, and the filter that shows them all. */
export type SearchKind = 'session' | 'project' | 'plugin' | 'skill' | 'shortcut' | 'action'
export type SearchFilter = SearchKind | 'all'

/** One palette row (see createSearchSources). */
export interface SearchRow {
  kind: SearchKind
  id: string
  title: string
  detail?: string
  snippet?: string
  snippetMatch?: [number, number] | null
  label?: string
  keys?: string[]
  icon?: string
  image?: string
  run(): void
}

/** One content hit from the host half's message search: the session, the excerpt, the match within it. */
export type { ContentHit } from '@dsh-claude-style/contracts/usage'

/** One section of the palette. */
export interface SearchSection {
  kind: SearchKind
  title: string
  rows: SearchRow[]
}

/**
 * Build palette rows from host services for sessions, projects, plugins,
 * skills, shortcuts and actions. Each row's `run` delegates to host navigation;
 * `reveal` jumps a picked content hit to its turn.
 */
export function createSearchSources(ctx: HostContext, reveal: (sessionId: string, seq: number) => void) {
  /** Rows per section when the palette shows every kind at once, and the cap for one kind. */
  const SECTION_LIMIT: Record<string, number> = { session: 6, project: 3, plugin: 3, skill: 3, shortcut: 3 }
  const KIND_LIMIT = 60
  /** Recent sessions the empty palette lists. */
  const RECENT_LIMIT = 5

  /** Plugins and skills are read once per palette opening; `null` until they answer. */
  let plugins: HostPluginBundle[] | null = null
  let skills: HostSkill[] | null = null
  let skillSessionId: string | null = null
  let generation = 0

  /** The host's shortcut row for a command id, for the keycaps an action row shows. */
  function commandKeys(id: string): string[] {
    const shortcuts = hostShortcuts(ctx)
    if (!shortcuts) return []
    const rows = shortcuts.catalog.getSnapshot()
    for (let i = 0; i < rows.length; i++) {
      if (rows[i].id === id) return rows[i].keys
    }
    return []
  }

  /** The store a host slot registration declares, e.g. the settings shell or the shortcut reference. */
  function slotStore(key: string, id?: string): HostSlotStore | null {
    const slots = hostSlots(ctx)
    if (!slots) return null
    const entries = slots.entries(key)
    for (let i = 0; i < entries.length; i++) {
      const entry = entries[i]
      if (id !== undefined && entry.options.id !== id) continue
      if (entry.store) return entry.store.create()
    }
    return null
  }

  function openShortcutReference(query: string) {
    const reference = slotStore('shell.overlay', 'shortcuts')
    if (reference === null) throw new Error('search: the shortcut reference is not registered')
    reference.actions.open()
    if (query) reference.actions.search(query)
  }

  /** Workspace title by session id, from the workspace list's own accounting. */
  function workspaceTitles(snapshot: HostWorkspaceListSnapshot) {
    const titles: Record<string, string> = {}
    for (let i = 0; i < snapshot.items.length; i++) {
      const workspace = snapshot.items[i]
      for (let s = 0; s < workspace.sessionIds.length; s++) {
        if (titles[workspace.sessionIds[s]] === undefined) titles[workspace.sessionIds[s]] = workspace.title
      }
    }
    return titles
  }

  /**
   * The sessions a person can open, newest first: the host's list minus
   * archived ones, subagent children and blank placeholders — the host
   * tree's own visibility rule with the archived filter off.
   */
  function openableSessions() {
    const sessions = hostSessions(ctx)
    const workspaces = hostWorkspaces(ctx)
    if (!sessions || !workspaces) return []
    const list = sessions.list.getSnapshot()
    const archive = workspaces.list.getSnapshot()
    const archived = new Set(archive.archivedSessionIds)
    const titles = workspaceTitles(archive)
    const rows: { summary: HostSessionSummary, workspace: string }[] = []
    for (let i = 0; i < list.ids.length; i++) {
      const summary = list.byId[list.ids[i]]
      if (summary === undefined || summary.blank || summary.origin === 'subagent' || archived.has(summary.id)) continue
      rows.push({ summary, workspace: titles[summary.id] || '' })
    }
    rows.sort((a, b) => b.summary.updatedAt - a.summary.updatedAt)
    return rows
  }

  /** A session row; `hit`, when given, is its content hit — the excerpt and the match within it. */
  function sessionRow(entry: { summary: HostSessionSummary, workspace: string }, hit?: ContentHit): SearchRow {
    const id = entry.summary.id
    return {
      kind: 'session',
      id: `session:${id}`,
      title: entry.summary.displayTitle,
      detail: entry.workspace,
      snippet: hit === undefined ? '' : hit.snippet,
      snippetMatch: hit === undefined ? null : hit.match,
      run() {
        hostUiWorkspace(ctx).openSession(id)
        // A content hit names the message it matched, so the conversation does
        // not stop at the session: the turn holding that message is revealed
        // once the session is the shown one.
        if (hit !== undefined) reveal(id, hit.seq)
      },
    }
  }

  function recentSessions() {
    return openableSessions().slice(0, RECENT_LIMIT).map(entry => sessionRow(entry))
  }

  /**
   * Sessions whose title or workspace name holds the query, newest first,
   * then the sessions whose messages hold it, newest hit first, each once
   * — the same merge the host's sidebar search makes. A title match that
   * also has a content hit shows its excerpt too.
   */
  function matchSessions(query: string, contentHits: ContentHit[]) {
    const q = query.toLowerCase()
    const entries = openableSessions()
    const byId: Record<string, { summary: HostSessionSummary, workspace: string }> = {}
    const hits: Record<string, ContentHit> = {}
    for (let h = 0; h < contentHits.length; h++) hits[contentHits[h].sessionId] = contentHits[h]
    const rows: SearchRow[] = []
    const included = new Set<string>()
    for (let i = 0; i < entries.length; i++) {
      const entry = entries[i]
      byId[entry.summary.id] = entry
      if (entry.summary.displayTitle.toLowerCase().includes(q) || entry.workspace.toLowerCase().includes(q)) {
        included.add(entry.summary.id)
        rows.push(sessionRow(entry, hits[entry.summary.id]))
      }
    }
    for (let c = 0; c < contentHits.length; c++) {
      const hit = contentHits[c]
      const entry = byId[hit.sessionId]
      if (entry === undefined || included.has(hit.sessionId)) continue
      included.add(hit.sessionId)
      rows.push(sessionRow(entry, hit))
    }
    return rows
  }

  /**
   * Ask the host half's message-content search (packages/host/src/search.ts): the
   * reader's own messages and the model's answers, matched as a literal
   * case-insensitive substring, so part of a Chinese sentence matches too. An
   * empty query only brings the host half's corpus up to date. Superseded
   * requests are aborted by the caller; a failure answers no hits, and the title
   * matches stand.
   * @returns the hits, newest first, `[{ sessionId, snippet, match }]`.
   */
  function searchContent(query: string, signal: AbortSignal | undefined): Promise<ContentHit[]> {
    const url = query === '' ? SESSION_SEARCH_ROUTE : `${SESSION_SEARCH_ROUTE}?q=${encodeURIComponent(query)}`
    return fetch(url, { credentials: 'same-origin', headers: { accept: 'application/json' }, signal }).then(response => {
      return response.json().then((body: SearchAnswer) => {
        if (!response.ok || !body.ok) throw new Error(`session search answered ${response.status}: ${body.error}`)
        return body.sessions ?? []
      })
    })
  }

  function projectRows(): SearchRow[] {
    const workspaces = hostWorkspaces(ctx)
    if (!workspaces) return []
    const items: HostWorkspaceListSnapshot['items'] = workspaces.list.getSnapshot().items
    return items.map(workspace => ({
      kind: 'project',
      id: `project:${workspace.workspaceId}`,
      title: workspace.title,
      detail: workspace.path,
      label: workspace.path,
      run() { hostUiWorkspace(ctx).startSession(workspace.workspaceId) },
    }))
  }

  function pluginText(value: unknown): string {
    const locale = hostLocale(ctx)
    const text = value === undefined ? undefined : locale?.resolveText?.(value)
    return typeof text === 'string' ? text : ''
  }

  /** The part of a package name a person reads: `@scope/name` → `name`. */
  function shortPackageName(name: string) {
    const slash = name.lastIndexOf('/')
    return slash === -1 ? name : name.slice(slash + 1)
  }

  function pluginRows(): SearchRow[] {
    if (plugins === null) return []
    return plugins.map(bundle => {
      const title = (bundle.meta && pluginText(bundle.meta.title)) || shortPackageName(bundle.name)
      return {
        kind: 'plugin',
        id: `plugin:${bundle.name}`,
        title,
        detail: (bundle.meta && pluginText(bundle.meta.description)) || bundle.description || '',
        image: bundle.meta && typeof bundle.meta.icon === 'string' ? bundle.meta.icon : '',
        label: bundle.name,
        run() { hostPluginNavigation(ctx).openBundle(bundle.name) },
      }
    })
  }

  /**
   * The profile's bundles, when the host manages a profile and can open a
   * bundle's page.
   * @returns a promise that settles once the list is in (or known absent).
   */
  function loadPlugins(owner: number): Promise<void> {
    const bundles = hostPluginNavigation(ctx) ? profileBundles(ctx) : null
    if (bundles === null) {
      plugins = []
      return Promise.resolve()
    }
    return bundles.then((list: HostPluginBundle[]) => {
      if (owner !== generation) return
      plugins = list.slice().sort((a, b) => shortPackageName(a.name).localeCompare(shortPackageName(b.name)))
    })
  }

  function currentOpenSession() {
    const sessions = hostSessions(ctx)
    if (!sessions) return null
    const id = currentSessionId(ctx)
    if (id === null) return null
    const binding = sessions.binding(id)
    if (!binding || !binding.session || binding.session.getSnapshot?.().openState !== 'open') return null
    return { id, binding }
  }

  /**
   * Put `/name ` at the head of the session's draft and hand the keyboard
   * back to the composer: a leading `/name` is how the host invokes a skill.
   */
  function insertSkill(binding: HostSessionBinding, name: string) {
    const conversation = hostConversation(binding.ctx)
    if (!conversation) throw new Error('search: the conversation service is not available')
    const input = conversation.input.for(binding.ctx)
    const draft = input.state.getSnapshot().draft
    input.setDraft(`/${name} ${draft.replace(/^\s+/, '')}`)
    input.focus()
  }

  function skillRows(): SearchRow[] {
    if (skills === null || skillSessionId === null) return []
    const sessions = hostSessions(ctx)
    const binding = sessions ? sessions.binding(skillSessionId) : null
    if (!binding) return []
    return skills.map(skill => ({
      kind: 'skill',
      id: `skill:${skill.name}`,
      title: `/${skill.name}`,
      detail: skill.description || '',
      label: skill.description || '',
      run() { insertSkill(binding, skill.name) },
    }))
  }

  function loadSkills(owner: number): Promise<void> {
    const open = currentOpenSession()
    const catalog = hostRemoteSkills(ctx)
    if (open === null || !catalog) {
      skills = []
      skillSessionId = null
      return Promise.resolve()
    }
    return catalog.list({ sessionId: open.id }).then((result: HostSkillListAnswer) => {
      if (!result.ok) throw new Error(result.error?.message ?? 'the skill catalog answered without a reason')
      if (owner !== generation) return
      skills = result.value.skills
      skillSessionId = open.id
    })
  }

  function shortcutRows() {
    const shortcuts = hostShortcuts(ctx)
    if (!shortcuts) return []
    const rows: SearchRow[] = []
    const seen = new Set<string>()
    const add = (entry: HostShortcutRow) => {
      const label = entry.label
      if (seen.has(entry.id) || label === undefined || label === '') return
      seen.add(entry.id)
      rows.push({
        kind: 'shortcut',
        id: `shortcut:${entry.id}`,
        title: label,
        keys: entry.keys,
        label: (entry.aliases || []).join(' '),
        run() { openShortcutReference(label) },
      })
    }
    shortcuts.catalog.getSnapshot().forEach(add)
    shortcuts.fixedCatalog.getSnapshot().forEach(add)
    return rows
  }

  function actionRows() {
    const rows: SearchRow[] = [{
      kind: 'action',
      id: 'action:new-session',
      icon: 'newSession',
      title: copy('searchActionNewSession'),
      keys: commandKeys('session.new'),
      run() { hostUiWorkspace(ctx).startSession() },
    }]
    if (hostPluginNavigation(ctx)) {
      rows.push({
        kind: 'action',
        id: 'action:plugins',
        icon: 'plugin',
        title: copy('searchActionPlugins'),
        run() { hostLayout(ctx).selectPanel('plugins') },
      })
    }
    if (slotStore('sidebar.settings') !== null) {
      rows.push({
        kind: 'action',
        id: 'action:settings',
        icon: 'settings',
        title: copy('searchActionSettings'),
        keys: commandKeys('settings.open'),
        run() { slotStore('sidebar.settings')?.actions.open() },
      })
    }
    if (slotStore('shell.overlay', 'shortcuts') !== null) {
      rows.push({
        kind: 'action',
        id: 'action:shortcuts',
        icon: 'shortcut',
        title: copy('searchActionShortcuts'),
        keys: commandKeys('shortcuts.open'),
        run() { openShortcutReference('') },
      })
    }
    return rows
  }

  /**
   * Rows of one kind that hold the query, best first. Matching is the host
   * sidebar search's own: a case-insensitive substring of the title or of
   * the row's second key (a path, a package name, a description, aliases).
   * A title that starts with the query leads, then one where a word starts
   * with it, then any title hit, then second-key hits; ties keep list order.
   */
  function ranked(rows: SearchRow[], query: string) {
    if (query === '') return rows
    const q = query.toLowerCase()
    const scored: { row: SearchRow, score: number, index: number }[] = []
    for (let i = 0; i < rows.length; i++) {
      const title = rows[i].title.toLowerCase()
      const at = title.indexOf(q)
      let score = -1
      if (at === 0) score = 0
      else if (at > 0 && /[\s\-_/.:]/.test(title.charAt(at - 1))) score = 1
      else if (at > 0) score = 2
      else if (rows[i].label?.toLowerCase().includes(q)) score = 3
      if (score !== -1) scored.push({ row: rows[i], score, index: i })
    }
    scored.sort((a, b) => a.score - b.score || a.index - b.index)
    return scored.map(entry => entry.row)
  }

  /**
   * Start a palette opening: forget the last one's plugins and skills and
   * read them again, since either may have changed while it was closed.
   * @param onLoaded - called whenever one of the two lists lands.
   */
  function open(onLoaded: () => void) {
    generation++
    const owner = generation
    plugins = null
    skills = null
    skillSessionId = null
    const settle = () => { if (owner === generation) onLoaded() }
    // The host half reads every stored session once before its first
    // answer; starting that as the palette opens keeps the first query quick.
    searchContent('', undefined).then(() => {}, reason => {
      console.warn('dsh-claude-style: session content search could not prepare:', reason)
    })
    loadPlugins(owner).then(settle, reason => {
      console.warn('dsh-claude-style: search could not list plugins:', reason)
      if (owner === generation) plugins = []
      settle()
    })
    loadSkills(owner).then(settle, reason => {
      console.warn('dsh-claude-style: search could not list skills:', reason)
      if (owner === generation) skills = []
      settle()
    })
  }

  function close() {
    generation++
  }

  /**
   * The sections for one query and one filter, in display order:
   * `[{ kind, title, rows }]`. Empty sections are left out.
   * @param query - the trimmed query.
   * @param filter - `all` or one kind.
   * @param contentHits - the host's content hits for this query, if any.
   */
  function sections(query: string, filter: SearchFilter, contentHits: ContentHit[]) {
    const out: SearchSection[] = []
    const push = (kind: SearchKind, title: string, rows: SearchRow[]) => {
      if (rows.length > 0) out.push({ kind, title, rows })
    }
    const limit = (kind: SearchKind) => filter === 'all' ? SECTION_LIMIT[kind] : KIND_LIMIT
    if (query === '' && filter === 'all') {
      push('session', copy('searchRecents'), recentSessions())
      push('action', copy('searchActions'), actionRows())
      return out
    }
    if (filter === 'all' || filter === 'session') {
      const rows = query === '' ? openableSessions().map(entry => sessionRow(entry)) : matchSessions(query, contentHits)
      push('session', copy('searchSessions'), rows.slice(0, limit('session')))
    }
    if (filter === 'all' || filter === 'project') push('project', copy('searchProjects'), ranked(projectRows(), query).slice(0, limit('project')))
    if (filter === 'all' || filter === 'plugin') push('plugin', copy('searchPlugins'), ranked(pluginRows(), query).slice(0, limit('plugin')))
    if (filter === 'all' || filter === 'skill') push('skill', copy('searchSkills'), ranked(skillRows(), query).slice(0, limit('skill')))
    if (filter === 'all' || filter === 'shortcut') push('shortcut', copy('searchShortcuts'), ranked(shortcutRows(), query).slice(0, limit('shortcut')))
    if (filter === 'all') push('action', copy('searchActions'), ranked(actionRows(), query))
    return out
  }

  /** Whether a kind is still waiting on its list, so the palette can say so instead of "no results". */
  function pending(filter: SearchFilter) {
    if (filter === 'plugin') return plugins === null
    if (filter === 'skill') return skills === null
    if (filter === 'all') return plugins === null || skills === null
    return false
  }

  return { open, close, sections, searchContent, pending }
}
