import * as React from 'react'
import { BRAND_INK_ACCENT, BRAND_INK_ORIGINAL, BRAND_INK_TEXT, BRANDS, PALETTE_COLORING_BRAND, PALETTE_COLORING_CUSTOM } from '../../constants'
import { PALETTE_CARDS } from 'virtual:dsh-claude-style/generated'
import { BrandLockup } from './settings-brand-lockup'
import { withoutTransition } from '../../shared/transition'
import type { SegmentOption, SettingsRow, SettingsView } from './settings-controls'
import type { Prefs } from '../../constants'
import { copy } from './copy'

/**
 * The Appearance tab's custom brand rows (D30), which open the tab: the switch
 * that keeps the sidebar's brand area on the page, then the brand area drawn as
 * the lockup the reader edits in place (settings-brand-lockup.ts), with how the
 * images are inked as its sub-row. The name and the two images are the reader's
 * own data, written through the page's write path and the host half's brand
 * routes, so the lockup edits the same values the sidebar paints. The colour
 * cards stand apart from them as Colours' sub-row (paletteCardsRow).
 */

/** One colour of a card: the preference it writes on the reader's card, and its name. */
const COLOURS = [
  { field: 'customAccent', label: 'paletteSwatchAccent', pick: (card: Card) => card.accent },
  { field: 'customCanvasLight', label: 'paletteSwatchLight', pick: (card: Card) => card.canvas.light },
  { field: 'customCanvasDark', label: 'paletteSwatchDark', pick: (card: Card) => card.canvas.dark },
  { field: 'customCode', label: 'paletteSwatchCode', pick: (card: Card) => card.code.light },
] as const

type Card = (typeof PALETTE_CARDS)[number]
type ColourField = (typeof COLOURS)[number]['field']

/** The brand cards in the settings page's brand order, each with the id the preference stores. */
const BRAND_CARDS = BRANDS.map((id) => {
  const card = PALETTE_CARDS.find((entry) => entry.id === id)
  if (card === undefined) throw new Error(`settings: the palette carries no ${id} card`)
  return { id, card }
})

/** The name a card goes by, in the settings page's own language. */
function cardName(card: Card) {
  return card.id === 'claude' ? copy('brandClaude') : copy('brandDeepseek')
}

/**
 * Puts the group's one hint over a disc (transitions.dev's "Tooltip open/close",
 * MIT): while it shows it travels there and takes the new label's width; while
 * it is hidden its place and width are written with transitions off, so only
 * the delayed appear plays.
 */
function placeHint(hint: HTMLElement, disc: HTMLElement, label: string) {
  const text = hint.firstElementChild as HTMLElement
  const showing = hint.hasAttribute('data-show')
  text.textContent = label
  const style = getComputedStyle(hint)
  const width = Math.ceil(text.scrollWidth + Number.parseFloat(style.paddingLeft) + Number.parseFloat(style.paddingRight))
  // offsetLeft, not the client rect: the disc's own lift and scale stay out of the measure.
  const x = disc.offsetLeft + disc.offsetWidth / 2 - width / 2
  const write = () => {
    hint.style.width = `${width}px`
    hint.style.setProperty('--dsh-claude-hint-x', `${x}px`)
  }
  if (showing) write()
  else withoutTransition([hint], write)
  hint.setAttribute('data-show', '')
}

/**
 * The four swatches of one card. A brand card's swatches are its colours as the
 * token sheet resolves them; the reader's card takes a colour well each, and
 * every pick switches the page to that card at once. The disc under the pointer
 * or the focus lifts its neighbours less the further they stand
 * (transitions.dev's "Avatar group hover", MIT) and names itself in the hint.
 */
function Swatches(props: { colours: string[], onChange?: (field: ColourField, value: string) => void }) {
  const { colours, onChange } = props
  const [lifted, setLifted] = React.useState<number | null>(null)
  const hint = React.useRef<HTMLSpanElement>(null)
  const point = (disc: HTMLElement, index: number) => {
    setLifted(index)
    placeHint(hint.current!, disc, copy(COLOURS[index].label))
  }
  const release = () => {
    setLifted(null)
    hint.current!.removeAttribute('data-show')
  }
  return React.createElement(
    'span',
    {
      className: 'dsh-claude-palette-swatches',
      'data-dsh-claude-lifting': lifted === null ? undefined : '',
      onPointerLeave: release,
    },
    COLOURS.map((colour, index) => {
      const label = copy(colour.label)
      const value = colours[index]
      const readOut = onChange === undefined
      return React.createElement(
        'span',
        {
          key: colour.field,
          className: 'dsh-claude-palette-swatch',
          style: {
            color: value,
            '--dsh-claude-lift-reach': lifted === null ? undefined : String(Math.abs(index - lifted)),
          } as React.CSSProperties,
          'data-dsh-claude-lifted': index === lifted ? '' : undefined,
          'aria-label': readOut ? label : undefined,
          role: readOut ? 'img' : undefined,
          onPointerEnter: (event: React.PointerEvent<HTMLSpanElement>) => point(event.currentTarget, index),
          // A brand disc takes no focus; the reader's discs take it through their colour wells.
          onFocus: (event: React.FocusEvent<HTMLSpanElement>) => point(event.currentTarget, index),
          onBlur: release,
        },
        onChange === undefined ? null : React.createElement('input', {
          type: 'color',
          className: 'dsh-claude-palette-swatch-input',
          value,
          'aria-label': label,
          onChange: (event: React.ChangeEvent<HTMLInputElement>) => onChange(colour.field, event.target.value),
        }),
      )
    }),
    // The discs carry their own names; the hint repeats them for the eye only.
    React.createElement(
      'span',
      { ref: hint, className: 'dsh-claude-palette-hint', 'aria-hidden': 'true' },
      React.createElement('span', { className: 'dsh-claude-palette-hint-text' }),
    ),
  )
}

/**
 * The three cards: the two brands' colour sets and the reader's own. Every card
 * can be picked: a brand card pins that card's colours whatever the theme style
 * says, and the card the page paints wears the selected border. Each picked
 * card offers "follow the brand again", which hands the colours back to the
 * brand the theme style chooses; the reader's four stay stored.
 */
function PaletteCards(props: { prefs: Prefs, write: SettingsView['write'] }) {
  const { prefs, write } = props
  const brand = PALETTE_CARDS.find((entry) => entry.id === prefs.brand) ?? PALETTE_CARDS[0]
  const following = prefs.paletteColors === PALETTE_COLORING_BRAND
  const custom = prefs.paletteColors === PALETTE_COLORING_CUSTOM
  const painted = following ? brand.id : prefs.paletteColors
  const reader = COLOURS.map((colour) => {
    const stored = prefs[colour.field]
    return stored === '' ? colour.pick(brand) : stored
  })
  const pick = (field: ColourField, value: string) => write({ paletteColors: PALETTE_COLORING_CUSTOM, [field]: value })
  const select = (colouring: Prefs['paletteColors']) => write({ paletteColors: colouring })
  const follow = () => write({ paletteColors: PALETTE_COLORING_BRAND })
  // Enter and Space on a card itself pick it; the reset and the colour wells
  // inside the card handle their own keys.
  const keyPick = (event: React.KeyboardEvent<HTMLDivElement>, run: () => void) => {
    if (event.target !== event.currentTarget || (event.key !== 'Enter' && event.key !== ' ')) return
    event.preventDefault()
    run()
  }
  const reset = (shown: boolean) => shown
    ? React.createElement('button', {
      type: 'button',
      className: 'dsh-claude-palette-reset',
      onClick: (event: React.MouseEvent<HTMLButtonElement>) => {
        event.stopPropagation()
        follow()
      },
    }, copy('paletteUseBrand'))
    : null
  return React.createElement(
    'div',
    { className: 'dsh-claude-palette-cards', role: 'group', 'aria-label': copy('paletteCardsTitle') },
    BRAND_CARDS.map(({ id, card }) => {
      const selected = !custom && id === painted
      return React.createElement(
        'div',
        {
          key: id,
          className: 'dsh-claude-palette-card',
          role: 'button',
          tabIndex: 0,
          'data-brand': id,
          'data-active': selected ? '' : undefined,
          'aria-pressed': selected ? 'true' : 'false',
          'aria-label': cardName(card),
          onClick: () => { if (!selected) select(id) },
          onKeyDown: (event: React.KeyboardEvent<HTMLDivElement>) => keyPick(event, () => { if (!selected) select(id) }),
        },
        React.createElement(Swatches, { colours: COLOURS.map((colour) => colour.pick(card)) }),
        React.createElement('span', { className: 'dsh-claude-palette-card-name' }, cardName(card)),
        reset(selected && !following),
      )
    }),
    React.createElement(
      'div',
      {
        className: 'dsh-claude-palette-card',
        role: 'button',
        tabIndex: 0,
        'data-active': custom ? '' : undefined,
        'aria-pressed': custom ? 'true' : 'false',
        'aria-label': copy('paletteCustom'),
        onClick: () => { if (!custom) select(PALETTE_COLORING_CUSTOM) },
        onKeyDown: (event: React.KeyboardEvent<HTMLDivElement>) => keyPick(event, () => { if (!custom) select(PALETTE_COLORING_CUSTOM) }),
      },
      React.createElement(Swatches, { colours: reader, onChange: pick }),
      React.createElement('span', { className: 'dsh-claude-palette-card-name' }, copy('paletteCustom')),
      reset(custom),
    ),
  )
}

/**
 * The colour cards as Colours' sub-row (D72): the two brands' colours as the
 * page paints them, and the reader's own four, which switch the page to that
 * card the moment one is picked. The row carries no title of its own.
 */
export function paletteCardsRow(view: SettingsView): SettingsRow {
  return {
    rank: 15,
    node: view.controls.row('paletteCards', null, null, React.createElement(PaletteCards, { prefs: view.prefs, write: view.write }), { block: true }),
  }
}

/**
 * The custom brand rows, ranked ahead of every other row on the tab: the switch
 * that keeps the sidebar's brand area on the page, the lockup the reader edits in
 * place under it (titleless, the way the colour cards follow Colours), and how
 * the images are inked as that block's sub-row.
 */
export function brandRows(view: SettingsView): SettingsRow[] {
  const { prefs, write } = view
  const inkOptions: SegmentOption<Prefs['brandInk']>[] = [
    { value: BRAND_INK_ORIGINAL, label: copy('brandInkOriginal') },
    { value: BRAND_INK_ACCENT, label: copy('brandInkAccent') },
    { value: BRAND_INK_TEXT, label: copy('brandInkText') },
  ]
  return [
    {
      rank: 5,
      node: view.controls.row(
        'sidebarBrand',
        copy('brandLockupTitle'),
        copy('brandLockupDesc'),
        view.controls.toggle(prefs.sidebarBrand, on => { write({ sidebarBrand: on }) }),
      ),
    },
    {
      rank: 6,
      node: view.controls.row(
        'brandLockup',
        null,
        null,
        React.createElement(BrandLockup, { prefs, write }),
        { block: true },
      ),
    },
    {
      rank: 7,
      node: view.controls.subRow(
        'brandInk',
        copy('brandInkTitle'),
        copy('brandInkDesc'),
        view.controls.segment(inkOptions, prefs.brandInk, value => { write({ brandInk: value }) }),
        true,
      ),
    },
  ]
}
