# 架构决策

本文件由 `npm run docs:index` 从各决策文件生成，勿手改。

每条决策记一个方向，正文只有背景、决定、后果与重审条件：放弃的方案写在后果一节，没有重审条件时写「无。」。编号是稳定标识，代码注释按编号引用；被取代或删除的编号作废、不复用。

| 编号 | 决策 | 取代 |
| --- | --- | --- |
| [D3](D3-host-selectors.md) | 宿主契约集中在契约模块 | D19、D44 |
| [D5](D5-model-copy.md) | 模型文案是数据 |  |
| [D9](D9-style-evidence.md) | CSS 的证据与令牌 | D4、D33、D37、D51、D65、D67 |
| [D12](D12-fail-fast.md) | 快速失败与功能隔离 |  |
| [D30](D30-palette-and-typeface.md) | 品牌与配色 | D50、D64 |
| [D36](D36-modules-and-bundling.md) | TypeScript、esbuild 与零运行时依赖 | D1 |
| [D40](D40-observation-bus.md) | 页面级资源各有唯一拥有者 | D6、D41、D26 |
| [D43](D43-overlay-and-upstream.md) | 依附宿主表面与宿主数据 | D2、D17 |
| [D47](D47-build-output.md) | 构建产物不进主分支 |  |
| [D48](D48-documentation.md) | 文档分层 |  |
| [D70](D70-clause-from-reasoning.md) | 从推理正文里读出的从句 |  |
| [D73](D73-contract-declares-engine-package.md) | 一个偏好一条声明，引擎自立一包 | D7 |
| [D74](D74-yield-whole-page.md) | 与其他插件共存，让路时整页交出 | D49、D23、D32、D55、D56、D57、D58、D63 |
| [D75](D75-private-routes.md) | 私有通道与安全边界 | D11 |
| [D76](D76-manifest-holds-facts.md) | 清单登记界面与构建要用的事实 | D42、D13、D29、D39、D72 |
| [D78](D78-sodium-rule-rewrite.md) | 改写宿主与插件的昂贵样式规则 |  |
| [D79](D79-model-rules-read-name.md) | 模型规则同时读标识与显示名 |  |
| [D80](D80-cost-snapshot-and-channel.md) | 价格与时段快照走仓库，会话费用由宿主半计价 |  |
| [D81](D81-page-scale-carries-host-cards.md) | 页面缩放留在样式表，宿主的浮层拿回一像素对一像素的空间 |  |
| [D83](D83-task-continuity-and-temporary-files.md) | 工单用于延续任务，临时文件独立退役 | D82 |
| [D84](D84-answer-first-line.md) | 正式回答的第一行是阅读位置的起点 |  |
| [D88](D88-borrowed-view-state-yields.md) | 借来的视图状态被改写时整页让开 |  |
| [D89](D89-sound-cues.md) | 提示音由宿主半播放系统声音，浏览器半只判断何时响 |  |
| [D90](D90-kept-row-heights.md) | 已看过的消息按上次高度跳过离屏排版 |  |
| [D91](D91-session-switch-broadcast.md) | 会话切换是一件广播出来的事 |  |
| [D92](D92-testing-evidence-and-selection.md) | 测试按证据分层，运行范围由一种选择器表达 | D87 |
| [D93](D93-canvas-per-block-motion.md) | 逐格独立相位的动效由一块画布绘制，令牌仍是唯一的取值来源 |  |
| [D94](D94-session-overview-details-rail.md) | 会话总览是对话右侧的详情栏，数据由宿主半边折叠 |  |
| [D95](D95-stream-slide-counter-pins.md) | 流式输出的跟随由宿主写位置，皮肤只画位移并抵消吸附元素的跳动 | D85、D71 |

## 作废的编号

D1（由 D36 取代）、D2（由 D43 取代）、D4（由 D9 取代）、D6（由 D40 取代）、D7（由 D73 取代）、D11（由 D75 取代）、D13（由 D76 取代）、D14（作废，无取代）、D16（作废，无取代）、D17（由 D43 取代）、D19（由 D3 取代）、D20（作废，无取代）、D21（作废，无取代）、D22（作废，无取代）、D23（由 D74 取代）、D24（作废，无取代）、D25（作废，无取代）、D26（由 D40 取代）、D27（作废，无取代）、D28（作废，无取代）、D29（由 D76 取代）、D31（作废，无取代）、D32（由 D74 取代）、D33（由 D9 取代）、D34（作废，无取代）、D35（作废，无取代）、D37（由 D9 取代）、D38（作废，无取代）、D39（由 D76 取代）、D41（由 D40 取代）、D42（由 D76 取代）、D44（由 D3 取代）、D49（由 D74 取代）、D50（由 D30 取代）、D51（由 D9 取代）、D52（作废，无取代）、D53（作废，无取代）、D54（作废，无取代）、D55（由 D74 取代）、D56（由 D74 取代）、D57（由 D74 取代）、D58（由 D74 取代）、D59（作废，无取代）、D61（作废，无取代）、D62（作废，无取代）、D63（由 D74 取代）、D64（由 D30 取代）、D65（由 D9 取代）、D67（由 D9 取代）、D68（作废，无取代）、D69（作废，无取代）、D71（由 D95 取代）、D72（由 D76 取代）、D82（由 D83 取代）、D85（由 D95 取代）、D87（由 D92 取代）。
